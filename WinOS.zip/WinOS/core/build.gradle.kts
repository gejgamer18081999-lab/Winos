plugins {
    id("org.jetbrains.kotlin.jvm")
}

// Чистый Kotlin/JVM без Android-зависимостей: этот модуль потом переносится на ПК как есть.
kotlin {
    jvmToolchain(17)
}
