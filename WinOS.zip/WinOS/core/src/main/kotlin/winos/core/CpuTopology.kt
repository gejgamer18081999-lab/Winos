package winos.core

import java.io.File

enum class CoreTier { LITTLE, BIG, PRIME }

/** Одно ядро CPU. Любое поле, кроме id, может быть неизвестно (SELinux/производитель). */
data class CpuCore(val id: Int, val maxKhz: Long = 0, val capacity: Int? = null, val part: Int? = null)

/**
 * Определяет, какие ядра слабые (LITTLE), какие мощные (BIG) и какое самое быстрое (PRIME).
 * Работает на любом Snapdragon без таблицы моделей: сначала смотрит модель ядра (Cortex part),
 * потом cpu_capacity, потом максимальную частоту.
 */
class CpuTopology(val cores: List<CpuCore>) {

    fun tiers(): Map<Int, CoreTier> {
        if (cores.size < 2) return cores.associate { it.id to CoreTier.BIG }
        val power: (CpuCore) -> Long = { it.capacity?.toLong() ?: it.maxKhz }
        val top = cores.maxOf(power)
        val allPartsKnown = cores.all { it.part != null }
        val topGroup = if (top > 0) cores.filter { power(it) >= top * 0.97 } else emptyList()
        return cores.associate { c ->
            val little = when {
                c.part != null && c.part in LITTLE_PARTS -> true
                allPartsKnown -> false
                top <= 0 -> false
                c.capacity != null -> power(c) < top * 0.5
                else -> power(c) < top * 0.72
            }
            val prime = !little && c in topGroup && topGroup.size <= 2 && topGroup.size < cores.size
            c.id to when {
                little -> CoreTier.LITTLE
                prime -> CoreTier.PRIME
                else -> CoreTier.BIG
            }
        }
    }

    /** Ядра для игры. По умолчанию без слабых: так планировщик Android не кидает потоки игры на A5xx. */
    fun gameCores(allowLittle: Boolean = false): List<Int> {
        val t = tiers()
        val ids = cores.filter { allowLittle || t[it.id] != CoreTier.LITTLE }.map { it.id }
        return ids.ifEmpty { cores.map { it.id } }
    }

    companion object {
        // Cortex-A520, A510, A55, A53, A35
        private val LITTLE_PARTS = setOf(0xd80, 0xd46, 0xd05, 0xd03, 0xd04)

        fun maskHex(ids: List<Int>): String =
            ids.fold(0L) { acc, i -> acc or (1L shl i) }.toString(16)

        fun read(
            sysCpu: File = File("/sys/devices/system/cpu"),
            procCpuinfo: File = File("/proc/cpuinfo"),
        ): CpuTopology {
            val parts = parseParts(procCpuinfo)
            val ids = sysCpu.listFiles()
                ?.mapNotNull { Regex("cpu(\\d+)").matchEntire(it.name)?.groupValues?.get(1)?.toIntOrNull() }
                ?.sorted()
                .orEmpty()
            val list = ids.map { id ->
                CpuCore(
                    id = id,
                    maxKhz = readText(File(sysCpu, "cpu$id/cpufreq/cpuinfo_max_freq"))?.toLongOrNull() ?: 0L,
                    capacity = readText(File(sysCpu, "cpu$id/cpu_capacity"))?.toIntOrNull(),
                    part = parts[id],
                )
            }
            return CpuTopology(list)
        }

        private fun readText(f: File): String? = runCatching { f.readText().trim() }.getOrNull()

        /** /proc/cpuinfo: «processor : N» и «CPU part : 0xd82» для каждого ядра. */
        private fun parseParts(f: File): Map<Int, Int> {
            val out = HashMap<Int, Int>()
            var cur = -1
            runCatching { f.readLines() }.getOrDefault(emptyList()).forEach { line ->
                val key = line.substringBefore(':').trim()
                val value = line.substringAfter(':', "").trim()
                when (key) {
                    "processor" -> cur = value.toIntOrNull() ?: -1
                    "CPU part" -> if (cur >= 0) value.removePrefix("0x").toIntOrNull(16)?.let { out[cur] = it }
                }
            }
            return out
        }
    }
}
