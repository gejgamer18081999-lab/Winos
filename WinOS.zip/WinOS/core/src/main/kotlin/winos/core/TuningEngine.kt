package winos.core

/** Насколько агрессивно ускорять Box64. Идти вверх по лестнице, пока игра не начнёт вылетать. */
enum class Box64Level { SAFE, FAST, UNSAFE }

enum class GameKind { DX9_32BIT, DX9, DX11, DX12, OPENGL }

/**
 * Собирает профиль запуска под конкретное устройство и игру.
 * Значения Box64 взяты из документации Box64 (USAGE.md); универсального «идеала» нет,
 * поэтому уровней три, а выбор подтверждается замером FPS, а не верой.
 */
object TuningEngine {

    fun box64Env(level: Box64Level): Map<String, String> = when (level) {
        Box64Level.SAFE -> mapOf(
            "BOX64_DYNAREC_BIGBLOCK" to "1",
            "BOX64_DYNAREC_SAFEFLAGS" to "2",
            "BOX64_DYNAREC_STRONGMEM" to "1",
            "BOX64_DYNAREC_FASTNAN" to "1",
            "BOX64_DYNAREC_FASTROUND" to "0",
            "BOX64_DYNAREC_CALLRET" to "0",
        )
        Box64Level.FAST -> mapOf(
            "BOX64_DYNAREC_BIGBLOCK" to "3",
            "BOX64_DYNAREC_SAFEFLAGS" to "1",
            "BOX64_DYNAREC_STRONGMEM" to "1",
            "BOX64_DYNAREC_FASTNAN" to "1",
            "BOX64_DYNAREC_FASTROUND" to "1",
            "BOX64_DYNAREC_CALLRET" to "1",
        )
        Box64Level.UNSAFE -> mapOf(
            "BOX64_DYNAREC_BIGBLOCK" to "3",
            "BOX64_DYNAREC_SAFEFLAGS" to "0",
            "BOX64_DYNAREC_STRONGMEM" to "0",
            "BOX64_DYNAREC_FASTNAN" to "1",
            "BOX64_DYNAREC_FASTROUND" to "1",
            "BOX64_DYNAREC_CALLRET" to "1",
        )
    }

    fun profile(
        name: String,
        kind: GameKind,
        level: Box64Level = Box64Level.FAST,
        cpu: CpuTopology = CpuTopology.read(),
        screenSize: String = "1280x720",
    ): Profile {
        val env = LinkedHashMap<String, String>()
        env.putAll(box64Env(level))
        // Кэш шейдеров DXVK: главный враг «просадок» после первого запуска — компиляция пайплайнов.
        if (kind != GameKind.OPENGL) env["DXVK_STATE_CACHE"] = "1"
        return Profile(
            name = name,
            graphicsDriver = "turnip",
            box64Preset = level.name.lowercase(),
            env = env,
            cpuAffinity = cpu.gameCores(allowLittle = false),
            screenSize = screenSize,
        )
    }
}
