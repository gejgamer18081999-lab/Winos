package winos.core

import java.io.File

/** Перевод путей между Windows-видом (D:\Games\game.exe) и реальными файлами. */
class WinPaths(private val drives: List<Drive>) {

    /** Реальный файл -> Windows-путь. Если файл вне дисков, возвращает исходный путь. */
    fun toWin(file: File): String {
        val abs = file.absoluteFile.normalize()
        // Сначала самый длинный корень, чтобы вложенные диски выигрывали.
        val drive = drives.sortedByDescending { it.root.path.length }
            .firstOrNull { abs.path == it.root.path || abs.path.startsWith(it.root.path + File.separator) }
            ?: return abs.path
        val rel = abs.path.removePrefix(drive.root.path).trimStart(File.separatorChar)
        return drive.winRoot + rel.replace(File.separatorChar, '\\')
    }

    /** Windows-путь -> реальный файл или null, если буква диска неизвестна. */
    fun toReal(winPath: String): File? {
        if (winPath.length < 2 || winPath[1] != ':') return null
        val drive = drives.firstOrNull { it.letter.equals(winPath[0], ignoreCase = true) } ?: return null
        val rel = winPath.substring(2).trimStart('\\', '/').replace('\\', File.separatorChar)
        return if (rel.isEmpty()) drive.root else File(drive.root, rel)
    }
}
