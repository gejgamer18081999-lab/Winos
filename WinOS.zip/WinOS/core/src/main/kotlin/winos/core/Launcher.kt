package winos.core

import java.io.File

/** Профиль запуска игры. Этап 3 (оптимизация) добавит сюда пресеты Box64/Turnip/DXVK. */
data class Profile(
    val name: String = "Default",
    val graphicsDriver: String = "turnip",
    val box64Preset: String = "performance",
    val env: Map<String, String> = emptyMap(),
)

/** Ярлык игры на рабочем столе. */
data class Shortcut(val name: String, val exePath: String, val profile: Profile = Profile())

sealed interface LaunchResult {
    data class Started(val pid: Long?) : LaunchResult
    data class Failed(val reason: String) : LaunchResult
}

/**
 * Единая точка запуска .exe. Android-реализация (Wine + Box64 + Turnip) появится на этапе 2,
 * ПК-реализация (системный Wine/Proton) позже. UI зависит только от этого интерфейса.
 */
interface RuntimeLauncher {
    fun isInstalled(): Boolean
    fun launch(exe: File, profile: Profile): LaunchResult
}

/** Заглушка этапа 1: рантайм ещё не подключён. */
class StubLauncher : RuntimeLauncher {
    override fun isInstalled() = false
    override fun launch(exe: File, profile: Profile): LaunchResult =
        LaunchResult.Failed("Рантайм (Wine/Box64) ещё не установлен. Это этап 2.")
}
