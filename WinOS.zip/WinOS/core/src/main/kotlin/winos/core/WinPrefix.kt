package winos.core

import java.io.File
import java.nio.file.Files

/** Один виртуальный диск Windows: буква, подпись и реальная папка на устройстве. */
data class Drive(val letter: Char, val label: String, val root: File) {
    val winRoot: String get() = "${letter.uppercaseChar()}:\\"
}

/**
 * Wine-prefix: C: лежит внутри данных приложения, D: это общее хранилище Android
 * (/storage/emulated/0). На ПК вместо хранилища Android передаётся любая папка.
 */
class WinPrefix(
    baseDir: File,
    private val sharedStorage: File,
) {
    val root = File(baseDir, "prefix")
    val driveC = File(root, "drive_c")
    private val dosDevices = File(root, "dosdevices")

    fun ensure() {
        listOf(
            "Windows/System32",
            "Program Files",
            "Program Files (x86)",
            "Users/user/Desktop",
            "Users/user/Documents",
        ).forEach { File(driveC, it).mkdirs() }
        dosDevices.mkdirs()
        link("c:", driveC)
        link("d:", sharedStorage)
    }

    fun drives(): List<Drive> = listOf(
        Drive('C', "Система", driveC),
        Drive('D', "Память устройства", sharedStorage),
    )

    private fun link(name: String, target: File) {
        val link = File(dosDevices, name).toPath()
        if (Files.isSymbolicLink(link)) return
        runCatching { Files.createSymbolicLink(link, target.toPath()) }
    }
}
