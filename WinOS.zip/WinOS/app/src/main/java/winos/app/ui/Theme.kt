package winos.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Accent = Color(0xFF4CC2FF)
val TaskbarColor = Color(0xE61B1F2A)
val WallpaperTop = Color(0xFF0B3D91)
val WallpaperBottom = Color(0xFF101528)

@Composable
fun WinOsTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(primary = Accent, background = WallpaperBottom, surface = Color(0xFF1B1F2A)),
        content = content,
    )
}
