package winos.app.ui

import android.widget.Toast
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import winos.app.WinEnv
import winos.core.LaunchResult
import winos.core.Shortcut
import java.io.File
import java.time.LocalTime
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Desktop(
    env: WinEnv,
    shortcuts: List<Shortcut>,
    onOpenExplorer: () -> Unit,
    onOpenAbout: () -> Unit,
    onRemoveShortcut: (Shortcut) -> Unit,
) {
    val context = LocalContext.current
    var menuFor by remember { mutableStateOf<Shortcut?>(null) }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(WallpaperTop, WallpaperBottom))),
    ) {
        Column(Modifier.fillMaxSize()) {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(88.dp),
                modifier = Modifier.weight(1f).statusBarsPadding().padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                item { DesktopIcon("🖥️", "Этот компьютер", onClick = onOpenExplorer) }
                items(shortcuts) { s ->
                    Box {
                        DesktopIcon(
                            icon = "🎮",
                            label = s.name,
                            onClick = {
                                val result = env.launcher.launch(File(s.exePath), s.profile)
                                if (result is LaunchResult.Failed) {
                                    Toast.makeText(context, result.reason, Toast.LENGTH_LONG).show()
                                }
                            },
                            onLongClick = { menuFor = s },
                        )
                        DropdownMenu(expanded = menuFor == s, onDismissRequest = { menuFor = null }) {
                            DropdownMenuItem(
                                text = { Text("Убрать с рабочего стола") },
                                onClick = { onRemoveShortcut(s); menuFor = null },
                            )
                        }
                    }
                }
            }
            Taskbar(onOpenExplorer = onOpenExplorer, onOpenAbout = onOpenAbout)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun DesktopIcon(icon: String, label: String, onClick: () -> Unit, onLongClick: (() -> Unit)? = null) {
    Column(
        Modifier
            .clip(RoundedCornerShape(8.dp))
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(icon, fontSize = 36.sp)
        Text(
            label,
            color = Color.White,
            fontSize = 12.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
private fun Taskbar(onOpenExplorer: () -> Unit, onOpenAbout: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    var time by remember { mutableStateOf(LocalTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            time = LocalTime.now()
            delay(15_000)
        }
    }

    Row(
        Modifier
            .fillMaxWidth()
            .background(TaskbarColor)
            .navigationBarsPadding()
            .height(52.dp)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box {
            Text(
                "⊞",
                color = Accent,
                fontSize = 26.sp,
                modifier = Modifier.clip(RoundedCornerShape(6.dp)).clickable { menu = true }.padding(horizontal = 10.dp),
            )
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("Проводник") }, onClick = { menu = false; onOpenExplorer() })
                DropdownMenuItem(text = { Text("О системе") }, onClick = { menu = false; onOpenAbout() })
            }
        }
        Box(Modifier.weight(1f))
        Text(time.format(DateTimeFormatter.ofPattern("HH:mm")), color = Color.White, fontSize = 14.sp)
    }
}
