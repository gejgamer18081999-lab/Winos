package winos.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import winos.app.WinEnv
import winos.core.Shortcut
import java.io.File

private enum class Screen { Desktop, Explorer, About }

@Composable
fun Root(env: WinEnv, hasAllFiles: Boolean, onRequestAccess: () -> Unit) {
    if (!hasAllFiles) {
        AccessGate(onRequestAccess)
        return
    }

    var screen by remember { mutableStateOf(Screen.Desktop) }
    val shortcuts = remember { mutableStateListOf<Shortcut>().apply { addAll(env.loadShortcuts()) } }

    fun addShortcut(exe: File) {
        if (shortcuts.any { it.exePath == exe.path }) return
        shortcuts += Shortcut(exe.nameWithoutExtension, exe.path)
        env.saveShortcuts(shortcuts.toList())
    }

    fun removeShortcut(s: Shortcut) {
        shortcuts.remove(s)
        env.saveShortcuts(shortcuts.toList())
    }

    BackHandler(enabled = screen != Screen.Desktop) { screen = Screen.Desktop }

    when (screen) {
        Screen.Desktop -> Desktop(
            env = env,
            shortcuts = shortcuts,
            onOpenExplorer = { screen = Screen.Explorer },
            onOpenAbout = { screen = Screen.About },
            onRemoveShortcut = ::removeShortcut,
        )
        Screen.Explorer -> Explorer(
            env = env,
            onClose = { screen = Screen.Desktop },
            onAddShortcut = ::addShortcut,
        )
        Screen.About -> About(env = env, onClose = { screen = Screen.Desktop })
    }
}

@Composable
private fun AccessGate(onRequestAccess: () -> Unit) {
    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("Нужен доступ к файлам", style = MaterialTheme.typography.headlineSmall)
            Text(
                "Диск D: это память телефона (/storage/emulated/0). Без доступа проводник не увидит игры.",
                modifier = Modifier.padding(vertical = 16.dp),
            )
            Button(onClick = onRequestAccess) { Text("Выдать доступ") }
        }
    }
}

@Composable
private fun About(env: WinEnv, onClose: () -> Unit) {
    Surface(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("WinOS 0.1", style = MaterialTheme.typography.headlineSmall)
            Text("Рантайм: ${if (env.launcher.isInstalled()) "установлен" else "не установлен (этап 2)"}")
            env.prefix.drives().forEach { Text("${it.winRoot}  →  ${it.root.path}") }
            Button(onClick = onClose) { Text("Закрыть") }
        }
    }
}
