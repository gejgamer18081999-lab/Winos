package winos.app.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import winos.app.WinEnv
import winos.core.LaunchResult
import java.io.File

private fun File.isExe() = isFile && extension.equals("exe", ignoreCase = true)

@Composable
fun Explorer(env: WinEnv, onClose: () -> Unit, onAddShortcut: (File) -> Unit) {
    val context = LocalContext.current
    val drives = remember { env.prefix.drives() }
    var dir by remember { mutableStateOf<File?>(null) } // null = «Этот компьютер»
    var selectedExe by remember { mutableStateOf<File?>(null) }

    fun goUp() {
        val current = dir ?: return onClose()
        dir = if (drives.any { it.root.path == current.path }) null else current.parentFile
    }

    BackHandler { goUp() }

    val entries = remember(dir) {
        dir?.listFiles()
            ?.sortedWith(compareByDescending<File> { it.isDirectory }.thenBy { it.name.lowercase() })
            ?: emptyList()
    }

    Surface(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("←", fontSize = 22.sp, modifier = Modifier.clickable { goUp() }.padding(end = 14.dp))
                Text(
                    dir?.let { env.paths.toWin(it) } ?: "Этот компьютер",
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                Text("✕", fontSize = 20.sp, modifier = Modifier.clickable { onClose() }.padding(start = 14.dp))
            }

            LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                if (dir == null) {
                    items(drives) { d ->
                        EntryRow("💽", "${d.label} (${d.letter}:)") { dir = d.root }
                    }
                } else {
                    if (entries.isEmpty()) {
                        item { Text("Папка пуста или нет доступа", Modifier.padding(16.dp)) }
                    }
                    items(entries, key = { it.path }) { f ->
                        when {
                            f.isDirectory -> EntryRow("📁", f.name) { dir = f }
                            f.isExe() -> EntryRow("🪟", f.name) { selectedExe = f }
                            else -> EntryRow("📄", f.name, onClick = null)
                        }
                    }
                }
            }
        }
    }

    selectedExe?.let { exe ->
        AlertDialog(
            onDismissRequest = { selectedExe = null },
            title = { Text(exe.name) },
            text = { Text(env.paths.toWin(exe)) },
            confirmButton = {
                TextButton(onClick = {
                    selectedExe = null
                    val result = env.launcher.launch(exe, winos.core.Profile())
                    if (result is LaunchResult.Failed) {
                        Toast.makeText(context, result.reason, Toast.LENGTH_LONG).show()
                    }
                }) { Text("Запустить") }
            },
            dismissButton = {
                TextButton(onClick = {
                    onAddShortcut(exe)
                    selectedExe = null
                    Toast.makeText(context, "Ярлык добавлен на рабочий стол", Toast.LENGTH_SHORT).show()
                }) { Text("На рабочий стол") }
            },
        )
    }
}

@Composable
private fun EntryRow(icon: String, name: String, onClick: (() -> Unit)?) {
    Row(
        Modifier
            .fillMaxWidth()
            .let { if (onClick != null) it.clickable(onClick = onClick) else it }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(icon, fontSize = 22.sp, modifier = Modifier.padding(end = 14.dp))
        Text(name, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
