package winos.app

import android.content.Context
import android.os.Environment
import org.json.JSONArray
import org.json.JSONObject
import winos.core.RuntimeLauncher
import winos.core.Shortcut
import winos.core.StubLauncher
import winos.core.WinPaths
import winos.core.WinPrefix
import java.io.File

/** Всё окружение «ОС»: prefix с дисками C:/D:, пути, ярлыки и лаунчер. */
class WinEnv private constructor(
    val prefix: WinPrefix,
    val paths: WinPaths,
    val launcher: RuntimeLauncher,
    private val shortcutsFile: File,
) {
    fun loadShortcuts(): List<Shortcut> = runCatching {
        val arr = JSONArray(shortcutsFile.readText())
        List(arr.length()) {
            val o = arr.getJSONObject(it)
            Shortcut(o.getString("name"), o.getString("exe"))
        }
    }.getOrDefault(emptyList())

    fun saveShortcuts(list: List<Shortcut>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("name", it.name).put("exe", it.exePath)) }
        shortcutsFile.writeText(arr.toString())
    }

    companion object {
        fun create(context: Context): WinEnv {
            val base = context.filesDir
            @Suppress("DEPRECATION")
            val shared = Environment.getExternalStorageDirectory() // /storage/emulated/0
            val prefix = WinPrefix(base, shared).also { it.ensure() }
            return WinEnv(
                prefix = prefix,
                paths = WinPaths(prefix.drives()),
                launcher = StubLauncher(),
                shortcutsFile = File(base, "shortcuts.json"),
            )
        }
    }
}
