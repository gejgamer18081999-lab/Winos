#!/usr/bin/env python3
"""Меняет OLD на NEW (строго одинаковой длины) во всех файлах и целях симлинков
внутри .tzst-архивов Winlator. Одинаковая длина => размеры и смещения не меняются.

Использование: rebrand_assets.py ASSETS_DIR OLD NEW
"""
import io
import os
import sys
import tarfile

import zstandard


def rewrite(src: str, dst: str, old: str, new: str):
    ob, nb = old.encode(), new.encode()
    files = links = 0
    with open(src, "rb") as fin, open(dst, "wb") as fout:
        reader = zstandard.ZstdDecompressor().stream_reader(fin)
        writer = zstandard.ZstdCompressor(level=12, threads=-1).stream_writer(fout)
        with tarfile.open(fileobj=reader, mode="r|", encoding="utf-8") as tin, \
                tarfile.open(fileobj=writer, mode="w|", format=tarfile.GNU_FORMAT, encoding="utf-8") as tout:
            for m in tin:
                if m.isreg():
                    data = tin.extractfile(m).read()
                    if ob in data:
                        data = data.replace(ob, nb)
                        files += 1
                    tout.addfile(m, io.BytesIO(data))
                else:
                    if m.issym() and old in m.linkname:
                        m.linkname = m.linkname.replace(old, new)
                        links += 1
                    tout.addfile(m)
        writer.close()
    return files, links


def main():
    assets, old, new = sys.argv[1:4]
    if len(old) != len(new):
        sys.exit(f"ОШИБКА: длины не равны ({len(old)} != {len(new)})")
    total_f = total_l = 0
    for root, _, names in os.walk(assets):
        for name in sorted(names):
            if not name.endswith(".tzst"):
                continue
            path = os.path.join(root, name)
            tmp = path + ".new"
            f, l = rewrite(path, tmp, old, new)
            os.replace(tmp, path)
            total_f += f
            total_l += l
            print(f"{os.path.relpath(path, assets)}: файлов {f}, ссылок {l}", flush=True)
    print(f"ИТОГО: файлов {total_f}, ссылок {total_l}")


if __name__ == "__main__":
    main()
