#!/usr/bin/env python3
"""WinOS: вшивает оптимизации в исходники Winlator перед сборкой.

Использование: tune_winlator.py MAIN   (MAIN = .../app/app/src/main)
Каждый патч мягкий: если якорь в исходниках не найден, печатается предупреждение,
а сборка продолжается (получится обычный Winlator без этого патча).
"""
import re
import shutil
import sys
from pathlib import Path

MAIN = Path(sys.argv[1])
HERE = Path(__file__).resolve().parent
results = []


def report(name, ok, note=""):
    results.append((name, ok, note))
    print(f"[{'OK' if ok else 'ПРОПУЩЕН'}] {name} {note}".rstrip(), flush=True)


def patch_file(path: Path, pattern: str, repl: str, name: str, flags=0):
    if not path.exists():
        return report(name, False, f"(нет файла {path.name})")
    text = path.read_text(encoding="utf-8")
    new, n = re.subn(pattern, repl, text, count=1, flags=flags)
    if n == 0:
        return report(name, False, "(якорь не найден)")
    path.write_text(new, encoding="utf-8")
    report(name, True)


# 1. Новый класс: выбор ядер без слабых.
core_dir = MAIN / "java/com/winlator/core"
if core_dir.is_dir():
    shutil.copy(HERE / "WinosTuning.java", core_dir / "WinosTuning.java")
    report("WinosTuning.java добавлен", True)
else:
    report("WinosTuning.java добавлен", False, "(нет папки core)")

container = MAIN / "java/com/winlator/container/Container.java"

# 2. Ядра CPU по умолчанию: без слабых (для нового контейнера, 64 и 32 бит).
patch_file(
    container,
    r'for \(int i = 0; i < numProcessors; i\+\+\) cpuList \+= \(!cpuList\.isEmpty\(\) \? "," : ""\)\+i;',
    "cpuList = com.winlator.core.WinosTuning.gameCpuList(numProcessors);",
    "Ядра CPU по умолчанию без слабых",
)

# 3. Пресет Box64 по умолчанию: PERFORMANCE.
patch_file(
    container,
    r"(DEFAULT_BOX64_PRESET\s*=\s*(?:com\.winlator\.box64\.)?Box64Preset\.)\w+",
    r"\1PERFORMANCE",
    "Пресет Box64 по умолчанию = PERFORMANCE",
)

# 4. Настройки Box64 для Source-игр (L4D2, HL2 и др.) в default.box64rc.
rc = MAIN / "assets/box64/default.box64rc"
SECTION = """
# --- WinOS: Source engine (Left 4 Dead 2, Half-Life 2 и др.) ---
[left4dead2.exe]
BOX64_DYNAREC_BIGBLOCK=3
BOX64_DYNAREC_SAFEFLAGS=1
BOX64_DYNAREC_STRONGMEM=1
BOX64_DYNAREC_FASTNAN=1
BOX64_DYNAREC_FASTROUND=1
BOX64_DYNAREC_CALLRET=1

[hl2.exe]
BOX64_DYNAREC_BIGBLOCK=3
BOX64_DYNAREC_SAFEFLAGS=1
BOX64_DYNAREC_STRONGMEM=1
BOX64_DYNAREC_FASTNAN=1
BOX64_DYNAREC_FASTROUND=1
BOX64_DYNAREC_CALLRET=1
"""
if rc.exists():
    t = rc.read_text(encoding="utf-8")
    if "[left4dead2.exe]" in t:
        report("default.box64rc: Source-игры", True, "(уже есть)")
    else:
        rc.write_text(t.rstrip("\n") + "\n" + SECTION, encoding="utf-8")
        report("default.box64rc: Source-игры", True)
else:
    report("default.box64rc: Source-игры", False, "(нет файла)")

print("\nИТОГО: применено %d из %d" % (sum(1 for _, ok, _ in results if ok), len(results)))
