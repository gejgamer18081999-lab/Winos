package com.winlator;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.Bitmap;
import android.graphics.drawable.Icon;
import android.widget.Toast;

import com.winlator.container.Shortcut;

import java.util.Locale;

/** WinOS: добавление ярлыка игры на рабочий стол телефона (закреплённый ярлык Android). */
public abstract class HomeShortcut {
    private static boolean isRussianOrUkrainian() {
        String lang = Locale.getDefault().getLanguage();
        return lang.equals("ru") || lang.equals("uk");
    }

    public static String menuTitle(Context context) {
        return isRussianOrUkrainian() ? "На рабочий стол телефона" : "Add to phone home screen";
    }

    public static void pin(Activity activity, Shortcut shortcut) {
        boolean ru = isRussianOrUkrainian();

        if (shortcut.file.isDirectory()) {
            Toast.makeText(activity, ru ? "Папку нельзя вынести на рабочий стол" : "Folders can't be pinned", Toast.LENGTH_SHORT).show();
            return;
        }

        ShortcutManager manager = activity.getSystemService(ShortcutManager.class);
        if (manager == null || !manager.isRequestPinShortcutSupported()) {
            Toast.makeText(activity, ru ? "Ваш лаунчер не поддерживает ярлыки на рабочем столе" : "Your launcher doesn't support pinned shortcuts", Toast.LENGTH_LONG).show();
            return;
        }

        Intent intent = new Intent(activity, ShortcutLauncherActivity.class);
        intent.setAction(Intent.ACTION_VIEW);
        intent.putExtra("container_id", shortcut.container.id);
        intent.putExtra("shortcut_path", shortcut.file.getPath());

        Icon icon;
        if (shortcut.icon != null) {
            Bitmap scaled = Bitmap.createScaledBitmap(shortcut.icon, 192, 192, true);
            icon = Icon.createWithBitmap(scaled);
        }
        else icon = Icon.createWithResource(activity, R.mipmap.ic_launcher);

        ShortcutInfo info = new ShortcutInfo.Builder(activity, "winos-" + shortcut.file.getPath().hashCode())
            .setShortLabel(shortcut.name)
            .setLongLabel(shortcut.name)
            .setIcon(icon)
            .setIntent(intent)
            .build();

        boolean requested = manager.requestPinShortcut(info, null);
        if (!requested) {
            Toast.makeText(activity, ru ? "Не удалось создать ярлык" : "Couldn't create the shortcut", Toast.LENGTH_SHORT).show();
        }
    }
}
