package com.winlator;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import java.io.File;
import java.io.IOException;

/**
 * WinOS: невидимая «прокладка». Ярлык на рабочем столе телефона открывает её,
 * а она сразу запускает игру в экране X-сервера и закрывается.
 */
public class ShortcutLauncherActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        launch();
        finish();
    }

    private void launch() {
        Intent source = getIntent();
        int containerId = source.getIntExtra("container_id", 0);
        String path = source.getStringExtra("shortcut_path");
        if (containerId <= 0 || path == null || path.isEmpty()) return;

        // Защита: ярлык обязан лежать внутри данных этого приложения (экспортируемая активность).
        try {
            File file = new File(path).getCanonicalFile();
            String appDir = getFilesDir().getParentFile().getCanonicalPath() + File.separator;
            if (!file.isFile() || !file.getPath().startsWith(appDir)) return;
        }
        catch (IOException e) {
            return;
        }

        Intent intent = new Intent(this, XServerDisplayActivity.class);
        intent.putExtra("container_id", containerId);
        intent.putExtra("shortcut_path", path);
        startActivity(intent);
    }
}
