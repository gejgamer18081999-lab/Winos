package com.winlator.core;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

/**
 * WinOS: авто-настройка под процессор устройства.
 * Игры и Wine по умолчанию привязываются только к «большим» ядрам:
 * маленькие энергоэффективные ядра (например A520 на Snapdragon 8s Gen 3) сильно тормозят потоки игры.
 * Определение идёт по максимальной частоте каждого ядра, поэтому работает на любом телефоне.
 */
public abstract class AutoTune {
    /** Ядро считается «маленьким», если его максимум ниже этой доли от самого быстрого ядра. */
    private static final float LITTLE_CORE_RATIO = 0.75f;
    /** Если после отсева осталось меньше ядер, используем все: так безопаснее. */
    private static final int MIN_BIG_CORES = 4;

    private static String cached;

    public static synchronized String performanceCpuList() {
        if (cached == null) cached = pick(readMaxFreqs());
        return cached;
    }

    /** Чистая функция для проверки логики: максимальные частоты ядер (кГц) -> список "3,4,5". */
    public static String pick(int[] maxFreqKhz) {
        int n = maxFreqKhz.length;
        int fastest = 0;
        for (int f : maxFreqKhz) fastest = Math.max(fastest, f);

        StringBuilder big = new StringBuilder();
        StringBuilder all = new StringBuilder();
        int bigCount = 0;
        for (int i = 0; i < n; i++) {
            if (all.length() > 0) all.append(',');
            all.append(i);
            if (fastest > 0 && maxFreqKhz[i] >= fastest * LITTLE_CORE_RATIO) {
                if (big.length() > 0) big.append(',');
                big.append(i);
                bigCount++;
            }
        }
        return fastest > 0 && bigCount >= MIN_BIG_CORES ? big.toString() : all.toString();
    }

    private static int[] readMaxFreqs() {
        int n = Math.max(1, Runtime.getRuntime().availableProcessors());
        int[] freqs = new int[n];
        for (int i = 0; i < n; i++) {
            File f = new File("/sys/devices/system/cpu/cpu" + i + "/cpufreq/cpuinfo_max_freq");
            try (BufferedReader r = new BufferedReader(new FileReader(f))) {
                String line = r.readLine();
                freqs[i] = line != null ? Integer.parseInt(line.trim()) : 0;
            }
            catch (Exception e) {
                freqs[i] = 0; // не смогли прочитать: pick() вернёт все ядра
            }
        }
        return freqs;
    }
}
