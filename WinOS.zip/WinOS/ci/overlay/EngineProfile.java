package com.winlator.core;

import java.io.File;

/**
 * WinOS: автоматические профили эмулятора под движок игры.
 *
 * Unity (Mono/IL2CPP) создаёт много потоков и генерирует код на лету. По документации Box64
 * для таких программ нужны мелкие блоки (BIGBLOCK), строгий порядок памяти (STRONGMEM)
 * и отказ от ожидания сборки блока (WAIT=0), иначе бывают тормоза и зависания.
 * Режим «Производительность» ставит обратное (BIGBLOCK=3, STRONGMEM=0), поэтому для Unity
 * значения переопределяются. Пользовательские переменные контейнера и ярлыка применяются
 * после профиля и имеют приоритет.
 */
public abstract class EngineProfile {
    public static boolean isUnity(String exeUnixPath) {
        if (exeUnixPath == null || exeUnixPath.isEmpty()) return false;
        File exe = new File(exeUnixPath);
        File dir = exe.getParentFile();
        if (dir == null || !dir.isDirectory()) return false;

        if (new File(dir, "UnityPlayer.dll").isFile()) return true;

        String name = exe.getName();
        int dot = name.lastIndexOf('.');
        String base = dot > 0 ? name.substring(0, dot) : name;
        File data = new File(dir, base + "_Data");
        return data.isDirectory() && (
            new File(data, "Managed").isDirectory() ||
            new File(data, "il2cpp_data").isDirectory() ||
            new File(data, "globalgamemanagers").isFile());
    }

    /** Применяет профиль к переменным окружения. Возвращает название профиля или null. */
    public static String applyBox64(EnvVars envVars, String exeUnixPath) {
        if (!isUnity(exeUnixPath)) return null;
        envVars.put("BOX64_DYNAREC_BIGBLOCK", "1");
        envVars.put("BOX64_DYNAREC_STRONGMEM", "1");
        envVars.put("BOX64_DYNAREC_WEAKBARRIER", "1");
        envVars.put("BOX64_DYNAREC_WAIT", "0");
        envVars.put("WINOS_PROFILE", "unity");
        return "unity";
    }
}
