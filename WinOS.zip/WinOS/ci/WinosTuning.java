package com.winlator.core;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Arrays;

/**
 * WinOS: выбор ядер CPU для игры по умолчанию. Слабые ядра (Cortex-A5xx) исключаются,
 * чтобы потоки игры не попадали на них. Работает на любом Snapdragon без таблицы моделей.
 * При любой неопределённости возвращает все ядра (поведение оригинального Winlator).
 */
public final class WinosTuning {
    private WinosTuning() {}

    private static final int[] LITTLE_PARTS = {0xd80, 0xd46, 0xd05, 0xd03, 0xd04};

    public static String gameCpuList(int n) {
        String all = allCores(n);
        try {
            if (n < 4) return all;
            long[] khz = new long[n];
            long[] cap = new long[n];
            int[] part = new int[n];
            Arrays.fill(part, -1);
            readParts(part);

            boolean allParts = true;
            boolean allCap = true;
            for (int i = 0; i < n; i++) {
                String base = "/sys/devices/system/cpu/cpu" + i;
                khz[i] = readLong(base + "/cpufreq/cpuinfo_max_freq");
                cap[i] = readLong(base + "/cpu_capacity");
                if (part[i] < 0) allParts = false;
                if (cap[i] <= 0) allCap = false;
            }
            long[] power = allCap ? cap : khz;
            long top = 0;
            for (long p : power) top = Math.max(top, p);
            if (top <= 0 && !allParts) return all;

            StringBuilder sb = new StringBuilder();
            int kept = 0;
            for (int i = 0; i < n; i++) {
                boolean little;
                if (part[i] >= 0 && isLittlePart(part[i])) little = true;
                else if (allParts) little = false;
                else if (top <= 0) little = false;
                else little = power[i] < top * (allCap ? 0.5 : 0.72);

                if (!little) {
                    if (sb.length() > 0) sb.append(',');
                    sb.append(i);
                    kept++;
                }
            }
            if (kept < 2 || kept == n) return all;
            return sb.toString();
        } catch (Throwable t) {
            return all;
        }
    }

    private static String allCores(int n) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) {
            if (i > 0) sb.append(',');
            sb.append(i);
        }
        return sb.toString();
    }

    private static boolean isLittlePart(int part) {
        for (int p : LITTLE_PARTS) if (p == part) return true;
        return false;
    }

    private static long readLong(String path) {
        try (BufferedReader r = new BufferedReader(new FileReader(new File(path)))) {
            String line = r.readLine();
            return line != null ? Long.parseLong(line.trim()) : -1;
        } catch (Throwable t) {
            return -1;
        }
    }

    /** /proc/cpuinfo: «processor : N», затем «CPU part : 0xd82». */
    private static void readParts(int[] part) {
        try (BufferedReader r = new BufferedReader(new FileReader("/proc/cpuinfo"))) {
            int cur = -1;
            String line;
            while ((line = r.readLine()) != null) {
                int idx = line.indexOf(':');
                if (idx < 0) continue;
                String key = line.substring(0, idx).trim();
                String value = line.substring(idx + 1).trim();
                if (key.equals("processor")) {
                    cur = Integer.parseInt(value);
                } else if (key.equals("CPU part") && cur >= 0 && cur < part.length) {
                    part[cur] = Integer.parseInt(value.startsWith("0x") ? value.substring(2) : value, 16);
                }
            }
        } catch (Throwable ignored) {
        }
    }
}
