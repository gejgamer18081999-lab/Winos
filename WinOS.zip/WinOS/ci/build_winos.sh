#!/usr/bin/env bash
# Собирает WinOS-основу: официальный Winlator 11.2 + своё имя пакета (com.winos.os).
# Запускается из GitHub Actions: bash WinOS/ci/build_winos.sh
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/.." && pwd)"
WORK="$ROOT/work"
OUT="$ROOT/out"

# Строки обязаны быть одинаковой длины (12 символов): путь вшит в бинарники образа.
OLD="com.winlator"
NEW="com.winos.os"
[ "${#OLD}" -eq "${#NEW}" ] || { echo "длины OLD/NEW не равны"; exit 1; }

rm -rf "$WORK" "$OUT"
mkdir -p "$WORK" "$OUT"

echo "::group::Клонирование Winlator 11.2"
git clone --depth 1 --branch v11.2.0 --recurse-submodules --shallow-submodules \
  https://github.com/brunodev85/winlator.git "$WORK/src"
echo "::endgroup::"

GRADLE_ROOT="$WORK/src/app"
MODULE="$GRADLE_ROOT/app"
MAIN="$MODULE/src/main"

echo "::group::Смена имени пакета и названия"
sed -i "s/applicationId '$OLD'/applicationId '$NEW'/" "$MODULE/build.gradle"
# две одинаковые нативные библиотеки в проекте: берём первую
sed -i "/compileSdk 34/a\    packagingOptions { pickFirst '**/*.so' }" "$MODULE/build.gradle"
# пути /data/data/<пакет>/ в исходниках (Java и нативный код)
grep -rlI "/data/data/$OLD" "$MAIN/java" "$MAIN/cpp" | xargs -r sed -i "s#/data/data/$OLD#/data/data/$NEW#g"
# название приложения
sed -i 's#<string name="app_name">Winlator</string>#<string name="app_name">WinOS</string>#' "$MAIN"/res/values*/strings.xml
echo "applicationId:"; grep -n "applicationId" "$MODULE/build.gradle"
echo "::endgroup::"

# защита: в исходниках не должно остаться старого пути
if grep -rnI "/data/data/$OLD" "$MAIN/java" "$MAIN/cpp"; then
  echo "ОШИБКА: старый путь остался в исходниках"; exit 1
fi

echo "::group::Оптимизация из коробки (WinOS AutoTune)"
JAVA_DIR="$MAIN/java/com/winlator"
cp "$HERE/overlay/AutoTune.java" "$JAVA_DIR/core/AutoTune.java"

# patch ФАЙЛ 'что искать' 'на что менять': падает, если искомого текста нет
patch() {
  local file="$1" from="$2" to="$3"
  grep -qF -- "$from" "$file" || { echo "ОШИБКА: в $file не найдено: $from"; exit 1; }
  python3 -I - "$file" "$from" "$to" <<'PY'
import sys
p, a, b = sys.argv[1:4]
s = open(p, encoding="utf-8").read()
open(p, "w", encoding="utf-8").write(s.replace(a, b, 1))
PY
  echo "  ok: $(basename "$file")"
}

# 1) Box64 по умолчанию в режиме «Производительность»
patch "$JAVA_DIR/box64/Box64Preset.java" \
  "DEFAULT = INTERMEDIATE;" "DEFAULT = PERFORMANCE;"
# 2) Ядра по умолчанию: только большие (без энергоэффективных)
patch "$JAVA_DIR/container/Container.java" \
  "public static String getFallbackCPUList() {" \
  "public static String getFallbackCPUList() {
        return com.winlator.core.AutoTune.performanceCpuList();
    }

    public static String getAllCpuList() {"
# 3) Счётчик FPS включён сразу (чтобы видеть результат настроек)
patch "$JAVA_DIR/container/Container.java" \
  "hudMode = (byte)FrameRating.Mode.DISABLED.ordinal();" \
  "hudMode = (byte)FrameRating.Mode.SIMPLE.ordinal();"
echo "::endgroup::"

echo "::group::Ярлыки игр на рабочем столе телефона"
cp "$HERE/overlay/HomeShortcut.java" "$JAVA_DIR/HomeShortcut.java"
cp "$HERE/overlay/ShortcutLauncherActivity.java" "$JAVA_DIR/ShortcutLauncherActivity.java"
# пункт меню «в избранное» в списке ярлыков скрыт: превращаем его в «На рабочий стол телефона»
patch "$JAVA_DIR/ShortcutsFragment.java" \
  "menu.findItem(R.id.menu_item_add_favorite).setVisible(false);" \
  "menu.findItem(R.id.menu_item_add_favorite).setTitle(com.winlator.HomeShortcut.menuTitle(context));"
patch "$JAVA_DIR/ShortcutsFragment.java" \
  "case R.id.menu_item_settings:" \
  "case R.id.menu_item_add_favorite:
                        com.winlator.HomeShortcut.pin(getActivity(), shortcut);
                        break;
                    case R.id.menu_item_settings:"
patch "$MAIN/AndroidManifest.xml" \
  "<provider" \
  "<activity android:name=\"com.winlator.ShortcutLauncherActivity\"
            android:exported=\"true\"
            android:excludeFromRecents=\"true\"
            android:taskAffinity=\"\"
            android:theme=\"@android:style/Theme.NoDisplay\" />

        <provider"
echo "::endgroup::"

echo "::group::Профили под движок игры (Unity)"
cp "$HERE/overlay/EngineProfile.java" "$JAVA_DIR/core/EngineProfile.java"
patch "$JAVA_DIR/XServerDisplayActivity.java" \
  "envVars.putAll(container.getEnvVars());" \
  "// WinOS: профиль эмулятора под движок игры. Ставится ДО переменных пользователя, их приоритет выше.
            String winosExe = shortcut != null ? com.winlator.core.WineUtils.dosToUnixPath(shortcut.path, container) : getIntent().getStringExtra(\"exec_path\");
            com.winlator.core.EngineProfile.applyBox64(envVars, winosExe);
            envVars.putAll(container.getEnvVars());"
echo "::endgroup::"

echo "::group::Замена пути внутри образа Wine, драйверов и Box64"
pip install --quiet zstandard
python3 -I "$HERE/rebrand_assets.py" "$MAIN/assets" "$OLD" "$NEW"
echo "::endgroup::"

echo "::group::Установка частей Android SDK"
SDKM="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"
yes | "$SDKM" --licenses > /dev/null || true
"$SDKM" "platforms;android-34" "ndk;24.0.8215888" "cmake;3.22.1" > /dev/null
echo "::endgroup::"

echo "::group::Сборка APK"
cd "$GRADLE_ROOT"
chmod +x gradlew
./gradlew assembleDebug --no-daemon
echo "::endgroup::"

cp "$MODULE"/build/outputs/apk/debug/*.apk "$OUT/WinOS-base-debug.apk"
ls -la "$OUT"
