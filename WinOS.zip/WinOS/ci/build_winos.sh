#!/usr/bin/env bash
# Собирает WinOS-основу: официальный Winlator 11.2 + своё имя пакета (com.winos.os).
# Запускается из GitHub Actions: bash WinOS/ci/build_winos.sh
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/.." && pwd)"
WORK="$ROOT/work"
OUT="$ROOT/out"

# Строки обязаны быть одинаковой длины (12 символов): путь вшит в бинарники образа.
OLD="com.winlator"
NEW="com.winos.os"
[ "${#OLD}" -eq "${#NEW}" ] || { echo "длины OLD/NEW не равны"; exit 1; }

rm -rf "$WORK" "$OUT"
mkdir -p "$WORK" "$OUT"

echo "::group::Клонирование Winlator 11.2"
git clone --depth 1 --branch v11.2.0 --recurse-submodules --shallow-submodules \
  https://github.com/brunodev85/winlator.git "$WORK/src"
echo "::endgroup::"

GRADLE_ROOT="$WORK/src/app"
MODULE="$GRADLE_ROOT/app"
MAIN="$MODULE/src/main"

echo "::group::Смена имени пакета и названия"
sed -i "s/applicationId '$OLD'/applicationId '$NEW'/" "$MODULE/build.gradle"
# две одинаковые нативные библиотеки в проекте: берём первую
sed -i "/compileSdk 34/a\    packagingOptions { pickFirst '**/*.so' }" "$MODULE/build.gradle"
# пути /data/data/<пакет>/ в исходниках (Java и нативный код)
grep -rlI "/data/data/$OLD" "$MAIN/java" "$MAIN/cpp" | xargs -r sed -i "s#/data/data/$OLD#/data/data/$NEW#g"
# название приложения
sed -i 's#<string name="app_name">Winlator</string>#<string name="app_name">WinOS</string>#' "$MAIN"/res/values*/strings.xml
echo "applicationId:"; grep -n "applicationId" "$MODULE/build.gradle"
echo "::endgroup::"

# защита: в исходниках не должно остаться старого пути
if grep -rnI "/data/data/$OLD" "$MAIN/java" "$MAIN/cpp"; then
  echo "ОШИБКА: старый путь остался в исходниках"; exit 1
fi

echo "::group::Замена пути внутри образа Wine, драйверов и Box64"
pip install --quiet zstandard
python3 -I "$HERE/rebrand_assets.py" "$MAIN/assets" "$OLD" "$NEW"
echo "::endgroup::"

echo "::group::Установка частей Android SDK"
SDKM="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"
yes | "$SDKM" --licenses > /dev/null || true
"$SDKM" "platforms;android-34" "ndk;24.0.8215888" "cmake;3.22.1" > /dev/null
echo "::endgroup::"

echo "::group::Сборка APK"
cd "$GRADLE_ROOT"
chmod +x gradlew
./gradlew assembleDebug --no-daemon
echo "::endgroup::"

cp "$MODULE"/build/outputs/apk/debug/*.apk "$OUT/WinOS-base-debug.apk"
ls -la "$OUT"
